"use strict";exports.id=506,exports.ids=[506],exports.modules={6249:(e,r)=>{Object.defineProperty(r,"l",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},2250:(e,r,t)=>{let n;t.r(r),t.d(r,{dbPath:()=>u,getDatabase:()=>E});var o=t(5315),s=t.n(o),a=t(2048),c=t.n(a);let i=s().join(process.cwd(),"data");c().existsSync(i)||c().mkdirSync(i,{recursive:!0});let u=s().join(i,"connect-plus.db");function E(){return n||((n=new(t(5890))(u,{verbose:void 0})).exec(`
    CREATE TABLE IF NOT EXISTS resources (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      url TEXT NOT NULL,
      icon TEXT,
      roles TEXT, -- Storing as JSON string
      needs TEXT, -- Storing as JSON string
      tags TEXT, -- Storing as JSON string
      featured INTEGER DEFAULT 0,
      updatedAt TEXT NOT NULL,
      resourceType TEXT NOT NULL,
      actionText TEXT DEFAULT 'View Resource'
    );
    
    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      icon TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );
    
    CREATE TABLE IF NOT EXISTS needs (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      icon TEXT NOT NULL,
      roles TEXT, -- Storing as JSON string
      createdAt TEXT,
      updatedAt TEXT
    );
    
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      createdAt TEXT,
      updatedAt TEXT
    );
  `),console.log("Database initialized at:",u)),n}},8047:(e,r,t)=>{t.a(e,async(e,n)=>{try{t.d(r,{CX:()=>h,ED:()=>S,F3:()=>T,MB:()=>u,Nd:()=>R,Rd:()=>A,SN:()=>E,fA:()=>f,fg:()=>l,h8:()=>m,id:()=>d,jh:()=>i,m1:()=>y,oi:()=>X,r4:()=>N,ul:()=>g,vL:()=>O,xQ:()=>p,y_:()=>L,yw:()=>P});var o=t(6555),s=e([o]);function a(e){if(Array.isArray(e))return e;if("string"==typeof e)try{let r=JSON.parse(e);return Array.isArray(r)?r:[e]}catch{return e?[e]:[]}return[]}function c(){let{getDatabase:e}=t(2250);return e()}async function i(){try{return c().prepare("SELECT * FROM resources ORDER BY updatedAt DESC").all().map(e=>({...e,roles:a(e.roles),needs:a(e.needs),tags:a(e.tags),featured:!!e.featured}))}catch(e){return console.error("SQLite fetch error:",e),[]}}async function u(e){try{let r=c().prepare("SELECT * FROM resources WHERE id = ?").get(e);if(!r)return null;return{...r,roles:a(r.roles),needs:a(r.needs),tags:a(r.tags),featured:!!r.featured}}catch(e){return console.error("Error fetching resource:",e),null}}async function E(e){try{let r=c(),t=(0,o.v4)();return r.prepare(`
      INSERT INTO resources (
        id, title, description, url, icon, roles, needs, tags, 
        featured, updatedAt, resourceType, actionText
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(t,e.title,e.description,e.url,e.icon,JSON.stringify(e.roles||[]),JSON.stringify(e.needs||[]),JSON.stringify(e.tags||[]),e.featured?1:0,e.updatedAt,e.resourceType,e.actionText||"View Resource"),{id:t,...e}}catch(e){return console.error("Error creating resource:",e),null}}async function d(e,r){try{let t=c(),n=t.prepare("SELECT * FROM resources WHERE id = ?").get(e);if(!n)return null;let o={...n,...r,roles:r.roles?JSON.stringify(r.roles):n.roles,needs:r.needs?JSON.stringify(r.needs):n.needs,tags:r.tags?JSON.stringify(r.tags):n.tags,featured:void 0!==r.featured?Number(r.featured):n.featured};return t.prepare(`
      UPDATE resources
      SET title = ?, description = ?, url = ?, icon = ?, roles = ?, 
          needs = ?, tags = ?, featured = ?, updatedAt = ?, 
          resourceType = ?, actionText = ?
      WHERE id = ?
    `).run(o.title,o.description,o.url,o.icon,o.roles,o.needs,o.tags,o.featured,o.updatedAt,o.resourceType,o.actionText,e),{...o,roles:a(o.roles),needs:a(o.needs),tags:a(o.tags),featured:!!o.featured}}catch(e){return console.error("Error updating resource:",e),null}}async function l(e){try{return c().prepare("DELETE FROM resources WHERE id = ?").run(e).changes>0}catch(e){return console.error("Error deleting resource:",e),!1}}async function T(){try{return c().prepare("SELECT * FROM roles ORDER BY name").all()}catch(e){return console.error("SQLite fetch error:",e),[]}}async function p(e){try{return c().prepare("SELECT * FROM roles WHERE id = ?").get(e)||null}catch(e){return console.error("Error fetching role:",e),null}}async function f(e){try{let r=c(),t=(0,o.v4)();return r.prepare(`
      INSERT INTO roles (id, name, description, icon, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(t,e.name,e.description,e.icon,e.createdAt,e.updatedAt),{id:t,...e}}catch(e){return console.error("Error creating role:",e),null}}async function g(e,r){try{let t=c(),n=t.prepare("SELECT * FROM roles WHERE id = ?").get(e);if(!n)return null;let o={...n,...r};return t.prepare(`
      UPDATE roles
      SET name = ?, description = ?, icon = ?, updatedAt = ?
      WHERE id = ?
    `).run(o.name,o.description,o.icon,o.updatedAt,e),o}catch(e){return console.error("Error updating role:",e),null}}async function A(e){try{return c().prepare("DELETE FROM roles WHERE id = ?").run(e).changes>0}catch(e){return console.error("Error deleting role:",e),!1}}async function y(){try{return c().prepare("SELECT * FROM needs ORDER BY name").all().map(e=>({...e,roles:a(e.roles)}))}catch(e){return console.error("SQLite fetch error:",e),[]}}async function S(e){try{let r=c().prepare("SELECT * FROM needs WHERE id = ?").get(e);if(!r)return null;return{...r,roles:a(r.roles)}}catch(e){return console.error("Error fetching need:",e),null}}async function R(e){try{let r=c(),t=(0,o.v4)(),n=JSON.stringify(e.roles||[]);return r.prepare(`
      INSERT INTO needs (id, name, description, icon, roles, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(t,e.name,e.description,e.icon,n,e.createdAt,e.updatedAt),{id:t,...e}}catch(e){return console.error("Error creating need:",e),null}}async function O(e,r){try{let t=c(),n=t.prepare("SELECT * FROM needs WHERE id = ?").get(e);if(!n)return null;let o={...n,...r,roles:r.roles?JSON.stringify(r.roles):n.roles};return t.prepare(`
      UPDATE needs
      SET name = ?, description = ?, icon = ?, roles = ?, updatedAt = ?
      WHERE id = ?
    `).run(o.name,o.description,o.icon,o.roles,o.updatedAt,e),{...o,roles:a(o.roles)}}catch(e){return console.error("Error updating need:",e),null}}async function L(e){try{return c().prepare("DELETE FROM needs WHERE id = ?").run(e).changes>0}catch(e){return console.error("Error deleting need:",e),!1}}async function N(e,r){try{let n=c(),s=t(8432);if(n.prepare("SELECT * FROM users WHERE email = ?").get(e))return null;let a=(0,o.v4)(),i=await s.hash(r,10),u=new Date().toISOString();return n.prepare(`
      INSERT INTO users (id, email, password, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?)
    `).run(a,e,i,u,u),{id:a,email:e}}catch(e){return console.error("Error creating user:",e),null}}function h(e){try{return c().prepare("SELECT * FROM users WHERE email = ?").get(e)||null}catch(e){return console.error("Error getting user by email:",e),null}}async function X(e,r){try{let n=c(),o=t(8432),s=await o.hash(r,10),a=new Date().toISOString();return n.prepare("UPDATE users SET password = ?, updatedAt = ? WHERE id = ?").run(s,a,e).changes>0}catch(e){return console.error("Error changing password:",e),!1}}function P(){try{return c().prepare("SELECT id, email, createdAt FROM users ORDER BY createdAt DESC").all()||[]}catch(e){return console.error("Error listing users:",e),[]}}function m(e){try{return c().prepare("DELETE FROM users WHERE id = ?").run(e).changes>0}catch(e){return console.error("Error deleting user:",e),!1}}o=(s.then?(await s)():s)[0],n()}catch(e){n(e)}})},7153:(e,r)=>{var t;Object.defineProperty(r,"x",{enumerable:!0,get:function(){return t}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(t||(t={}))},1802:(e,r,t)=>{e.exports=t(145)}};