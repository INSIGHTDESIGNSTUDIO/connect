exports.id=992,exports.ids=[992],exports.modules={8012:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.d(t,{b:()=>c,i:()=>d});var s=r(997),i=r(6689),o=r(1492),a=e([o]);o=(a.then?(await a)():a)[0];let u=(0,i.createContext)({step:1,selectedRoles:[],selectedNeeds:[],resources:[],filteredResources:[],searchTerm:"",availableRoles:[],nextStep:()=>{},prevStep:()=>{},setStep:()=>{},toggleRole:()=>{},toggleNeed:()=>{},clearSelections:()=>{},setSearchTerm:()=>{}});function c(){return(0,i.useContext)(u)}function d({children:e}){let[t,r]=(0,i.useState)(1),[n,o]=(0,i.useState)([]),[a,c]=(0,i.useState)([]),[d,l]=(0,i.useState)(""),[T,p]=(0,i.useState)([]),[E,g]=(0,i.useState)([]),[f,S]=(0,i.useState)(!0),m=T.filter(e=>0===n.length||Array.isArray(e.roles)&&e.roles.some(e=>n.includes(e))).filter(e=>0===a.length||Array.isArray(e.needs)&&e.needs.some(e=>a.includes(e))).filter(e=>{if(!d)return!0;let t=d.toLowerCase();return e.title.toLowerCase().includes(t)||e.description.toLowerCase().includes(t)||Array.isArray(e.tags)&&e.tags.some(e=>e.toLowerCase().includes(t))});return s.jsx(u.Provider,{value:{step:t,selectedRoles:n,selectedNeeds:a,resources:T,filteredResources:m,searchTerm:d,availableRoles:E,loading:f,nextStep:()=>r(e=>Math.min(e+1,3)),prevStep:()=>r(e=>Math.max(e-1,1)),setStep:e=>r(e),toggleRole:e=>{o(t=>{let r=t.includes(e)?t.filter(t=>t!==e):[...t,e];return c([]),r})},toggleNeed:e=>{c(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])},clearSelections:()=>{o([]),c([]),l("")},setSearchTerm:l},children:e})}n()}catch(e){n(e)}})},1675:(e,t,r)=>{"use strict";let n;r.r(t),r.d(t,{dbPath:()=>d,getDatabase:()=>u});var s=r(5315),i=r.n(s),o=r(2048),a=r.n(o);let c=i().join(process.cwd(),"data");a().existsSync(c)||a().mkdirSync(c,{recursive:!0});let d=i().join(c,"connect-plus.db");function u(){return n||((n=new(r(5890))(d,{verbose:void 0})).exec(`
    CREATE TABLE IF NOT EXISTS resources (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      url TEXT NOT NULL,
      icon TEXT,
      roles TEXT, -- Storing as JSON string
      needs TEXT, -- Storing as JSON string
      tags TEXT, -- Storing as JSON string
      featured INTEGER DEFAULT 0,
      updatedAt TEXT NOT NULL,
      resourceType TEXT NOT NULL,
      actionText TEXT DEFAULT 'View Resource'
    );
    
    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      icon TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );
    
    CREATE TABLE IF NOT EXISTS needs (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      icon TEXT NOT NULL,
      roles TEXT, -- Storing as JSON string
      createdAt TEXT,
      updatedAt TEXT
    );
    
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      createdAt TEXT,
      updatedAt TEXT
    );
  `),console.log("Database initialized at:",d)),n}},1492:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.d(t,{F3:()=>l,MB:()=>c,SN:()=>d,_:()=>E,id:()=>u,jf:()=>p,m1:()=>T,rj:()=>g});var s=r(6555),i=e([s]);function o(e){if(Array.isArray(e))return e;if("string"==typeof e)try{let t=JSON.parse(e);return Array.isArray(t)?t:[e]}catch{return e?[e]:[]}return[]}function a(){let{getDatabase:e}=r(1675);return e()}async function c(e){try{let t=a().prepare("SELECT * FROM resources WHERE id = ?").get(e);if(!t)return null;return{...t,roles:o(t.roles),needs:o(t.needs),tags:o(t.tags),featured:!!t.featured}}catch(e){return console.error("Error fetching resource:",e),null}}async function d(e){try{let t=a(),r=(0,s.v4)();return t.prepare(`
      INSERT INTO resources (
        id, title, description, url, icon, roles, needs, tags, 
        featured, updatedAt, resourceType, actionText
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,e.title,e.description,e.url,e.icon,JSON.stringify(e.roles||[]),JSON.stringify(e.needs||[]),JSON.stringify(e.tags||[]),e.featured?1:0,e.updatedAt,e.resourceType,e.actionText||"View Resource"),{id:r,...e}}catch(e){return console.error("Error creating resource:",e),null}}async function u(e,t){try{let r=a(),n=r.prepare("SELECT * FROM resources WHERE id = ?").get(e);if(!n)return null;let s={...n,...t,roles:t.roles?JSON.stringify(t.roles):n.roles,needs:t.needs?JSON.stringify(t.needs):n.needs,tags:t.tags?JSON.stringify(t.tags):n.tags,featured:void 0!==t.featured?Number(t.featured):n.featured};return r.prepare(`
      UPDATE resources
      SET title = ?, description = ?, url = ?, icon = ?, roles = ?, 
          needs = ?, tags = ?, featured = ?, updatedAt = ?, 
          resourceType = ?, actionText = ?
      WHERE id = ?
    `).run(s.title,s.description,s.url,s.icon,s.roles,s.needs,s.tags,s.featured,s.updatedAt,s.resourceType,s.actionText,e),{...s,roles:o(s.roles),needs:o(s.needs),tags:o(s.tags),featured:!!s.featured}}catch(e){return console.error("Error updating resource:",e),null}}async function l(){try{return a().prepare("SELECT * FROM roles ORDER BY name").all()}catch(e){return console.error("SQLite fetch error:",e),[]}}async function T(){try{return a().prepare("SELECT * FROM needs ORDER BY name").all().map(e=>({...e,roles:o(e.roles)}))}catch(e){return console.error("SQLite fetch error:",e),[]}}s=(i.then?(await i)():i)[0];let p=[{id:"mock-1",title:"Sample Resource",description:"This is a mock resource shown if SQLite fetch fails.",url:"https://example.com",resourceType:"Guide",icon:"FileText",roles:["HE Lecturer"],needs:["Unit Development"],tags:["mock","sample"],featured:!1,updatedAt:"2025-01-01"}],E=[{id:"mock-1",name:"HE Lecturer",description:"Teaching in higher education institutions",icon:"BookOpen"},{id:"mock-2",name:"VET/TAFE Lecturer",description:"Teaching in vocational education settings",icon:"School"},{id:"mock-3",name:"Unit Coordinator",description:"Coordinating and managing educational units",icon:"Briefcase"},{id:"mock-4",name:"Professional Staff",description:"Supporting educational delivery and operations",icon:"Users"},{id:"mock-5",name:"New to Teaching",description:"Recently started teaching in any setting",icon:"GraduationCap"}],g=[{id:"mock-1",name:"Teaching Resources",description:"Materials and guides for classroom teaching",icon:"BookOpen",roles:["mock-1","mock-2","mock-5"],createdAt:"2023-01-01",updatedAt:"2023-01-01"},{id:"mock-2",name:"Unit Development",description:"Resources for developing and planning course units",icon:"FileText",roles:["mock-1","mock-3"],createdAt:"2023-01-01",updatedAt:"2023-01-01"},{id:"mock-3",name:"Student Support",description:"Resources for helping students succeed",icon:"Users",roles:["mock-1","mock-2","mock-4"],createdAt:"2023-01-01",updatedAt:"2023-01-01"}];n()}catch(e){n(e)}})},3893:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.r(t),r.d(t,{default:()=>u});var s=r(997);r(108);var i=r(968),o=r.n(i),a=r(1649),c=r(8012),d=e([c]);function u({Component:e,pageProps:{session:t,...r}}){return s.jsx(a.SessionProvider,{session:t,children:(0,s.jsxs)(c.i,{children:[(0,s.jsxs)(o(),{children:[s.jsx("title",{children:"Connect Us"}),s.jsx("meta",{name:"description",content:"Connect with educational resources tailored to your role and needs"}),s.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),s.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),s.jsx(e,{...r})]})})}c=(d.then?(await d)():d)[0],n()}catch(e){n(e)}})},108:()=>{}};